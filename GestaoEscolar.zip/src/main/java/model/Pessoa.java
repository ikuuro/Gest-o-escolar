/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ikaro
 */
public abstract class Pessoa {
    private String nome;
    private int idade;
    private static int countPessoa;

    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
        ++countPessoa;
    }

    public abstract void atividade();

    public String getNome() {
        return this.nome;
    }

    public int getIdade() {
        return this.idade;
    }

    public static int getCountPessoa() {
        return countPessoa;
    }
}

