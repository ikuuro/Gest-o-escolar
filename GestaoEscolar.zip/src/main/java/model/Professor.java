/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ikaro
 */
import control.Pessoas;

public class Professor extends Pessoa implements Pessoas {
    private static int countProfessor;
    private int RegisFuncional;

    public Professor(String nome, int idade) {
        super(nome, idade);
        ++countProfessor;
        this.RegisFuncional = countProfessor;
    }

    public void atividade() {
        System.out.println("Ministrando aula...");
    }

    public int getId() {
        return this.RegisFuncional;
    }
}

