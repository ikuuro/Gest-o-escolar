/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ikaro
 */
import control.Pessoas;

public class Aluno extends Pessoa implements Pessoas {
    private int matricula;
    private static int countAluno;

    public Aluno(String nome, int idade) {
        super(nome, idade);
        ++countAluno;
        this.matricula = countAluno;
    }

    public void atividade() {
        System.out.println("Praticando flauta");
    }

    public int getId() {
        return this.matricula;
    }
}
