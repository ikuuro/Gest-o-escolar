/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author ikaro
 */
import java.util.ArrayList;
import model.Aluno;
import model.Funcionario;
import model.Pessoa;
import model.Professor;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Aluno caio = new Aluno("Caio", 16);
        Aluno fernanda = new Aluno("Fernanda", 17);
        Professor marcio = new Professor("Marcio", 32);
        Professor joana = new Professor("Joana", 40);
        Funcionario paulo = new Funcionario("Paulo", 39);
        ArrayList<Pessoa> escola = new ArrayList();
        escola.add(caio);
        escola.add(paulo);
        escola.add(joana);
        escola.add(fernanda);
        escola.add(marcio);
        int tamanho = escola.size();

        for(int i = 0; i < tamanho; ++i) {
            ((Pessoa)escola.get(i)).atividade();
        }

        System.out.println("\n");
        System.out.println("Matricula do aluno " + caio.getNome() + " -> " + " " + caio.getId());
        System.out.println("Numero do cracha " + paulo.getNome() + " -> " + " " + paulo.getId());
        System.out.println("Registro de professor " + joana.getNome() + " -> " + " " + joana.getId());
        System.out.println("Matricula do aluno " + fernanda.getNome() + " -> " + " " + fernanda.getId());
        System.out.println("Registro de professor " + marcio.getNome() + " -> " + " " + marcio.getId());
    }
}
